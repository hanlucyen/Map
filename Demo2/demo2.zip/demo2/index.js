(function (window) {
    'use strict';

    function initMap() {
        var control;
        var L = window.L;
            // Tạo một lớp tileLayer sử dụng dữ liệu Google Maps
        var google = L.tileLayer('https://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}', 
            { zIndex: 50, opacity: 1, maxZoom: 24, subdomains: ["mt0", "mt1", "mt2", "mt3"] 
            });

            // Tạo một đối tượng map với các tùy chọn và thêm lớp tileLayer vào đó
        var map = L.map('map', {
            center: [10.7769, 106.7009],
            zoom: 13
        }).addLayer(google);


            //định nghĩa thuộc tính của đối tượng
        var style = {
            color: 'yellow',
            opacity: 1.0,
            fillOpacity: 0.2,
            weight: 1,
            clickable: true
        };
        // Thiết lập hình ảnh biểu tượng cho nút tải lên file
        L.Control.FileLayerLoad.LABEL = '<img class="icon" src="folder.svg" alt="file icon"/>';
        // Tạo và cấu hình nút tải lên fileLayerLoad control
        control = L.Control.fileLayerLoad({
            fitBounds: true,
            layerOptions: {
                style: style,
                pointToLayer: function (data, latlng) {
                    return L.circleMarker(
                        latlng,
                        { style: style }
                    );
                }
            }
        });
        //thêm control vào map 
        control.addTo(map);

        control.loader.on('data:loaded', function (e) {
            var layer = e.layer;
            console.log(layer);
        });
    }

    window.addEventListener('load', function () {
        initMap();
    });
}(window));
